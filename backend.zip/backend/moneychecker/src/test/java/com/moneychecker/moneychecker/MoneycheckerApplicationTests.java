package com.moneychecker.moneychecker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneycheckerApplicationTests {

	@Test
	void contextLoads() {
	}

}
