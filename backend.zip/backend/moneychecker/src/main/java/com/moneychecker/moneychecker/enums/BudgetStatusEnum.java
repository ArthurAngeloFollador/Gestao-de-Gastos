package com.moneychecker.moneychecker.enums;

public enum BudgetStatusEnum {
    ACTIVE,
    CANCELLED,
    COMPLETED;
}
