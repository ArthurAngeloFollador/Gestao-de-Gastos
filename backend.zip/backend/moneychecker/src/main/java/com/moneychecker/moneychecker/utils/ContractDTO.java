package com.moneychecker.moneychecker.utils;

/**
 * Interface utilizada para definir quais classes/records representam um (D)ata
 * (T)ransfer (O)bject
 */
public interface ContractDTO {
    public Object getId();
}