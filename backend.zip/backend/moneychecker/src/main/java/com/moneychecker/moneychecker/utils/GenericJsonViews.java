package com.moneychecker.moneychecker.utils;

public class GenericJsonViews {
    public static class Public{};
    public static class Internal extends Public{};
}