package com.moneychecker.moneychecker.utils;

/**
 * Classe auxiliar utilizada para definir comportamento de validação de campos
 */
public class ValidationGroups {
    public interface Create {
    }

    public interface Update {
    }

    public interface Delete {
    }

    public interface Find {
    }
}